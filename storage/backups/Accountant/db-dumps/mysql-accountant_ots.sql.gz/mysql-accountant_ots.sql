
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` bigint unsigned DEFAULT NULL,
  `properties` json DEFAULT NULL,
  `batch_uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject` (`subject_type`,`subject_id`),
  KEY `causer` (`causer_type`,`causer_id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,'Group','Group has been created','App\\Models\\Group','created','24f1fc78-966b-419c-94e7-4f05bc24deee',NULL,NULL,'[]',NULL,'2024-12-18 18:45:18','2024-12-18 18:45:18'),(2,'Entry','Entry has been created','App\\Models\\Entry','created','2df0722c-3a04-4040-87c8-c0ec89b33be4',NULL,NULL,'[]',NULL,'2024-12-18 18:47:24','2024-12-18 18:47:24'),(3,'EntryItem','EntryItem has been created','App\\Models\\EntryItem','created','395c8ba7-a624-415b-9aab-f43a91079fc8',NULL,NULL,'[]',NULL,'2024-12-18 18:47:24','2024-12-18 18:47:24'),(4,'EntryItem','EntryItem has been created','App\\Models\\EntryItem','created','63bbc47f-62bb-466f-a471-7cde7334cb72',NULL,NULL,'[]',NULL,'2024-12-18 18:47:24','2024-12-18 18:47:24'),(5,'Entry','Entry has been updated','App\\Models\\Entry','updated','2df0722c-3a04-4040-87c8-c0ec89b33be4',NULL,NULL,'[]',NULL,'2024-12-18 18:48:07','2024-12-18 18:48:07'),(6,'EntryItem','EntryItem has been created','App\\Models\\EntryItem','created','e520ee6c-7de1-4455-bbb6-8ddf2ca515d2',NULL,NULL,'[]',NULL,'2024-12-18 18:48:07','2024-12-18 18:48:07'),(7,'EntryItem','EntryItem has been created','App\\Models\\EntryItem','created','c8ad3988-10ad-4dd3-80f3-cbae8928caa8',NULL,NULL,'[]',NULL,'2024-12-18 18:48:07','2024-12-18 18:48:07'),(8,'EntryItem','EntryItem has been created','App\\Models\\EntryItem','created','40576f32-e712-47d3-a7f7-34080c5203fb',NULL,NULL,'{\"attributes\": {\"dc\": \"D\", \"amount\": \"200.00\", \"entry_id\": \"2df0722c-3a04-4040-87c8-c0ec89b33be4\", \"ledger_id\": \"4c794fbb-05b6-4708-95ce-0c4a4d9451d5\", \"narration\": \"dsadsa\", \"reconciliation_date\": null}}',NULL,'2024-12-18 18:50:14','2024-12-18 18:50:14'),(9,'EntryItem','EntryItem has been created','App\\Models\\EntryItem','created','b7a0b866-94a2-4a35-94a0-86773dda31bf',NULL,NULL,'{\"attributes\": {\"dc\": \"C\", \"amount\": \"200.00\", \"entry_id\": \"2df0722c-3a04-4040-87c8-c0ec89b33be4\", \"ledger_id\": \"909917cb-1080-4a34-b4b3-1b16d0a74c4a\", \"narration\": \"dsa\", \"reconciliation_date\": null}}',NULL,'2024-12-18 18:50:14','2024-12-18 18:50:14'),(10,'Entry','Entry has been updated','App\\Models\\Entry','updated','2df0722c-3a04-4040-87c8-c0ec89b33be4',NULL,NULL,'{\"old\": {\"cr_total\": \"200.00\"}, \"attributes\": {\"cr_total\": \"2002.00\"}}',NULL,'2024-12-18 18:50:17','2024-12-18 18:50:17'),(11,'EntryItem','EntryItem has been created','App\\Models\\EntryItem','created','b2da584f-82e4-47c8-8fa3-172ebf5d86e9',NULL,NULL,'{\"attributes\": {\"dc\": \"D\", \"amount\": \"200.00\", \"entry_id\": \"2df0722c-3a04-4040-87c8-c0ec89b33be4\", \"ledger_id\": \"4c794fbb-05b6-4708-95ce-0c4a4d9451d5\", \"narration\": \"dsadsa\", \"reconciliation_date\": null}}',NULL,'2024-12-18 18:50:17','2024-12-18 18:50:17'),(12,'EntryItem','EntryItem has been created','App\\Models\\EntryItem','created','77f25cf4-f1a8-4e41-9a31-6c609ddee6bc',NULL,NULL,'{\"attributes\": {\"dc\": \"C\", \"amount\": \"2002.00\", \"entry_id\": \"2df0722c-3a04-4040-87c8-c0ec89b33be4\", \"ledger_id\": \"909917cb-1080-4a34-b4b3-1b16d0a74c4a\", \"narration\": \"dsa\", \"reconciliation_date\": null}}',NULL,'2024-12-18 18:50:17','2024-12-18 18:50:17');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numeric_value` bigint DEFAULT NULL,
  `text_value` text COLLATE utf8mb4_unicode_ci,
  `json_value` json DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entrytype_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` bigint DEFAULT NULL,
  `date` date NOT NULL,
  `dr_total` decimal(25,2) NOT NULL DEFAULT '0.00',
  `cr_total` decimal(25,2) NOT NULL DEFAULT '0.00',
  `narration` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entries_entrytype_id_foreign` (`entrytype_id`),
  KEY `entries_tag_id_foreign` (`tag_id`),
  CONSTRAINT `entries_entrytype_id_foreign` FOREIGN KEY (`entrytype_id`) REFERENCES `entrytypes` (`id`),
  CONSTRAINT `entries_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES ('2df0722c-3a04-4040-87c8-c0ec89b33be4','bb293202-1b00-4013-9261-e92522e04d86','fbc108f4-bbd9-11ef-b531-95983b5d208a',123,'2024-12-18',200.00,2002.00,NULL,'2024-12-18 18:47:24','2024-12-18 18:50:17'),('c87ffb5b-786a-4e27-af62-a25d4d9dab12','f7221af1-307e-44c9-9245-8423da303a79','fbc108f4-bbd9-11ef-b531-95983b5d208a',1,'2024-12-15',50.00,50.00,NULL,'2024-12-15 16:43:29','2024-12-15 20:06:28'),('c87ffb5b-786a-4e27-af62-a25d4d9dab60','f7221af1-307e-44c9-9245-8423da303a79','fbc108f4-bbd9-11ef-b531-95983b5d208a',2,'2024-12-18',220.00,220.00,NULL,'2024-12-15 16:43:29','2024-12-15 20:06:28');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `entry_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entry_items` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entry_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ledger_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(25,2) NOT NULL DEFAULT '0.00',
  `dc` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reconciliation_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `narration` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entry_items_entry_id_foreign` (`entry_id`),
  KEY `entry_items_ledger_id_foreign` (`ledger_id`),
  CONSTRAINT `entry_items_entry_id_foreign` FOREIGN KEY (`entry_id`) REFERENCES `entries` (`id`),
  CONSTRAINT `entry_items_ledger_id_foreign` FOREIGN KEY (`ledger_id`) REFERENCES `ledgers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `entry_items` WRITE;
/*!40000 ALTER TABLE `entry_items` DISABLE KEYS */;
INSERT INTO `entry_items` VALUES ('25f63fe2-23a2-490b-971b-440f24f543fc','c87ffb5b-786a-4e27-af62-a25d4d9dab60','4c794fbb-05b6-4708-95ce-0c4a4d9451d5',100.00,'D','2024-12-01','2024-12-15 20:06:28','2024-12-15 20:06:28','dsad'),('3ffc807f-183a-471b-b827-45c3634bb280','c87ffb5b-786a-4e27-af62-a25d4d9dab60','c235d75b-9019-409f-8b64-e399462a5789',120.00,'D',NULL,'2024-12-15 20:06:28','2024-12-15 20:06:28','4'),('6a82d85d-7980-4966-8a2d-a4fd3f8a22b1','c87ffb5b-786a-4e27-af62-a25d4d9dab60','4c794fbb-05b6-4708-95ce-0c4a4d9451d5',100.00,'C','2024-12-25','2024-12-15 20:06:28','2024-12-15 20:06:28','sdasdas'),('77f25cf4-f1a8-4e41-9a31-6c609ddee6bc','2df0722c-3a04-4040-87c8-c0ec89b33be4','909917cb-1080-4a34-b4b3-1b16d0a74c4a',2002.00,'C',NULL,'2024-12-18 18:50:17','2024-12-18 18:50:17','dsa'),('b2da584f-82e4-47c8-8fa3-172ebf5d86e9','2df0722c-3a04-4040-87c8-c0ec89b33be4','4c794fbb-05b6-4708-95ce-0c4a4d9451d5',200.00,'D',NULL,'2024-12-18 18:50:17','2024-12-18 18:50:17','dsadsa'),('dbd8ba6d-c428-40d6-a0a0-b3050a67f818','c87ffb5b-786a-4e27-af62-a25d4d9dab60','909917cb-1080-4a34-b4b3-1b16d0a74c4a',120.00,'C',NULL,'2024-12-15 20:06:28','2024-12-15 20:06:28','sada');
/*!40000 ALTER TABLE `entry_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_type` int NOT NULL DEFAULT '0',
  `numbering` int NOT NULL DEFAULT '1',
  `prefix` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `suffix` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zero_padding` int NOT NULL DEFAULT '0',
  `restriction_bankcash` int NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entrytypes_label_unique` (`label`),
  UNIQUE KEY `entrytypes_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES ('fbc108f4-bbd9-11ef-b531-95983b5d208a','receipt','Receipt','Received in Bank account or Cash account',1,1,'','',0,2,NULL,NULL),('fbc122ee-bbd9-11ef-b531-95983b5d208a','payment','Payment','Payment made from Bank account or Cash account',1,1,'','',0,3,NULL,NULL),('fbc139fa-bbd9-11ef-b531-95983b5d208a','contra','Contra','Transfer between Bank account and Cash account',1,1,'','',0,4,NULL,NULL),('fbc13e96-bbd9-11ef-b531-95983b5d208a','journal','Journal','Transfer between Non Bank account and Cash account',1,1,'202406','',0,5,NULL,NULL);
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `groups` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `affects_gross` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`),
  UNIQUE KEY `groups_code_unique` (`code`),
  KEY `groups_parent_id_foreign` (`parent_id`),
  CONSTRAINT `groups_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES ('0eee0ab5-7626-4030-81e2-cae16feb514b',NULL,'Liabilities and Owners Equity','04',0,'2024-10-13 14:29:38','2024-10-13 14:30:00'),('24f1fc78-966b-419c-94e7-4f05bc24deee','6d58085c-ff7e-436f-9a12-8681a5b465d1','2test','testads',0,'2024-12-18 18:45:18','2024-12-18 18:46:28'),('312d0817-89c8-43cc-a4b7-d60b9a520c60',NULL,'Incomes','03',0,'2024-10-13 14:29:20','2024-10-13 14:29:57'),('6d58085c-ff7e-436f-9a12-8681a5b465d1',NULL,'Expenses','02',0,'2024-10-13 14:29:27','2024-10-13 14:29:53'),('dbf6c3ce-ac93-4ac5-b356-19ecc049e545',NULL,'Assets','01',0,'2024-10-13 14:28:59','2024-10-13 14:29:49'),('f7919424-74d5-40fa-a32f-c3d5d77037c0','dbf6c3ce-ac93-4ac5-b356-19ecc049e545','testdd','testttest',0,'2024-12-18 18:41:51','2024-12-18 18:46:54');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ledgers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ledgers` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `op_balance` decimal(25,2) NOT NULL DEFAULT '0.00',
  `op_balance_dc` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `reconciliation` tinyint(1) NOT NULL DEFAULT '0',
  `notes` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ledgers_name_unique` (`name`),
  UNIQUE KEY `ledgers_code_unique` (`code`),
  KEY `ledgers_group_id_foreign` (`group_id`),
  CONSTRAINT `ledgers_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ledgers` WRITE;
/*!40000 ALTER TABLE `ledgers` DISABLE KEYS */;
INSERT INTO `ledgers` VALUES ('4c794fbb-05b6-4708-95ce-0c4a4d9451d5','dbf6c3ce-ac93-4ac5-b356-19ecc049e545','Cash book1','011',21.00,'D',1,1,'0','2024-10-13 14:30:45','2024-10-13 14:33:07'),('909917cb-1080-4a34-b4b3-1b16d0a74c4a','6d58085c-ff7e-436f-9a12-8681a5b465d1','Rent','04',0.00,'D',0,0,'0','2024-10-13 14:31:32','2024-10-13 14:31:32'),('972d0709-e309-481a-a760-79740adf3f5c','0eee0ab5-7626-4030-81e2-cae16feb514b','Notes payable','02',0.00,'D',0,0,'0','2024-10-13 14:31:06','2024-10-13 14:31:06'),('c235d75b-9019-409f-8b64-e399462a5789','312d0817-89c8-43cc-a4b7-d60b9a520c60','Sales','03',0.00,'D',0,0,'0','2024-10-13 14:31:21','2024-10-13 14:31:21');
/*!40000 ALTER TABLE `ledgers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2024_06_12_115002_create_groups_table',1),(2,'2024_06_12_115016_create_ledgers_table',1),(3,'2024_06_12_115030_create_entrytypes_table',1),(4,'2024_06_12_115044_create_tags_table',1),(5,'2024_06_12_115100_create_entries_table',1),(6,'2024_06_12_115110_create_entryitems_table',1),(7,'2024_06_12_115133_create_config_table',1),(11,'2024_12_18_182326_create_activity_log_table',2),(12,'2024_12_18_182327_add_event_column_to_activity_log_table',2),(13,'2024_12_18_182328_add_batch_uuid_column_to_activity_log_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `background` char(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_title_unique` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES ('5e4feca2-31bd-481a-ab22-0dc8ea19c022','1test','#FFF','#FFF','2024-12-15 17:33:56','2024-12-15 17:34:14'),('bb293202-1b00-4013-9261-e92522e04d86','#FFFa','#FFF','#000','2024-12-15 17:34:02','2024-12-15 17:34:02'),('f7221af1-307e-44c9-9245-8423da303a79','test','test','test','2024-10-13 14:32:01','2024-10-13 14:32:01');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

